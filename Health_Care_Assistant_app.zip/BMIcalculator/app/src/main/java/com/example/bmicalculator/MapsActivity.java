package com.example.bmicalculator;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.bmicalculator.databinding.ActivityMapsBinding;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        /** coordinates for health care markers in zambia */

        /** UTH */
        LatLng UTH = new LatLng(-15.432071,28.313674);
        mMap.addMarker(new MarkerOptions().position(UTH).title("UTH"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(UTH));


        /** Levy_Mwanawasa_General_Hospital */
        LatLng Levy_Mwanawasa_General_Hospital = new LatLng(-15.31972,28.67718);
        mMap.addMarker(new MarkerOptions().position(Levy_Mwanawasa_General_Hospital).title("Levy_Mwanawasa_General_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Levy_Mwanawasa_General_Hospital));

        /** Chipata_General_Hospital */
        LatLng Chipata_General_Hospital = new LatLng(-13.6419415,32.6375592);
        mMap.addMarker(new MarkerOptions().position(Chipata_General_Hospital).title("Chipata_General_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Chipata_General_Hospital));

        /** Kitwe_Central_Hospital */
        LatLng Kitwe_Central_Hospital = new LatLng(-12.797289,28.210995);
        mMap.addMarker(new MarkerOptions().position(Kitwe_Central_Hospital).title("Kitwe_Central_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Kitwe_Central_Hospital));

        /** Konkola_Mine_Hospital */
        LatLng Konkola_Mine_Hospital = new LatLng(-12.3707747,27.822133);
        mMap.addMarker(new MarkerOptions().position(Konkola_Mine_Hospital).title("Konkola_Mine_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Konkola_Mine_Hospital));

        /** Lubwe_Mission_Hospital */
        LatLng Lubwe_Mission_Hospital = new LatLng(-11.11421,29.64414);
        mMap.addMarker(new MarkerOptions().position(Lubwe_Mission_Hospital).title("Lubwe_Mission_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Lubwe_Mission_Hospital));

        /** Maacha_Hospital */
        LatLng Maacha_Hospital = new LatLng(-16.3922135, 26.791286);
        mMap.addMarker(new MarkerOptions().position(Maacha_Hospital).title("Maacha_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Maacha_Hospital));

        /** Mtendere_Mission_Hospital */
        LatLng Mtendere_Mission_Hospital = new LatLng(-16.02783, 28.855711);
        mMap.addMarker(new MarkerOptions().position(Mtendere_Mission_Hospital).title("Mtendere_Mission_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Mtendere_Mission_Hospital));

        /** Mwandi_Mission_Hospital */
        LatLng Mwandi_Mission_Hospital = new LatLng(-17.516403,24.816752);
        mMap.addMarker(new MarkerOptions().position(Mwandi_Mission_Hospital).title("Mwandi_Mission_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Mwandi_Mission_Hospital));

        /** Nchanga_North_Hospital */
        LatLng Nchanga_North_Hospital = new LatLng(-12.524958, 27.861179);
        mMap.addMarker(new MarkerOptions().position(Nchanga_North_Hospital).title("Nchanga_North_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Nchanga_North_Hospital));

        /** St_Francis_Hospital */
        LatLng St_Francis_Hospital = new LatLng(-14.0659636626, 32.0149326324);
        mMap.addMarker(new MarkerOptions().position(St_Francis_Hospital).title("St_Francis_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(St_Francis_Hospital));

        /** St_Lukes_Mission_Hospital */
        LatLng St_Lukes_Mission_Hospital = new LatLng(-15.10868,29.72505);
        mMap.addMarker(new MarkerOptions().position(St_Lukes_Mission_Hospital).title("St_Lukes_Mission_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(St_Lukes_Mission_Hospital));

        /** Lewanika_Provincial_Hospital */
        LatLng Lewanika_Provincial_Hospital = new LatLng(-15.26422,23.1383);
        mMap.addMarker(new MarkerOptions().position(Lewanika_Provincial_Hospital).title("Lewanika_Provincial_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Lewanika_Provincial_Hospital));

        /** Ndola_Central_Hospital */
        LatLng Ndola_Central_Hospital = new LatLng(-12.96916,28.63389);
        mMap.addMarker(new MarkerOptions().position(Ndola_Central_Hospital).title("Ndola_Central_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Ndola_Central_Hospital));

        /** Hilltop_Hospital */
        LatLng Hilltop_Hospital = new LatLng( -12.97756,28.63954);
        mMap.addMarker(new MarkerOptions().position(Hilltop_Hospital).title("Hilltop_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Hilltop_Hospital));

        /** Mumbwa_District_Hospital */
        LatLng Mumbwa_District_Hospital = new LatLng( -14.97599,27.05363);
        mMap.addMarker(new MarkerOptions().position(Mumbwa_District_Hospital).title("Mumbwa_District_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Mumbwa_District_Hospital));

        /** Mpanshya_Mission_Hospital */
        LatLng Mpanshya_Mission_Hospital = new LatLng( -15.10803,29.72529);
        mMap.addMarker(new MarkerOptions().position(Mpanshya_Mission_Hospital).title("Mpanshya_Mission_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Mpanshya_Mission_Hospital));

        /** Chilenje_Clinic */
        LatLng Chilenje_Clinic = new LatLng( -15.44983,28.33728);
        mMap.addMarker(new MarkerOptions().position(Chilenje_Clinic).title("Chilenje_Clinic"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Chilenje_Clinic));

        /** Kamwala_Clinic */
        LatLng Kamwala_Clinic = new LatLng(-15.428506,28.289685);
        mMap.addMarker(new MarkerOptions().position(Kamwala_Clinic).title("Kamwala_Clinic"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Kamwala_Clinic));

        /** Chainama_Hills_Collage_Hospital */
        LatLng Chainama_Hills_Collage_Hospital = new LatLng(-15.3898648,28.3554118);
        mMap.addMarker(new MarkerOptions().position(Chainama_Hills_Collage_Hospital).title("Chainama_Hills_Collage_Hospital"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Chainama_Hills_Collage_Hospital));


    }
}

/**JUBA MATEMATE SIN:2106671544 */