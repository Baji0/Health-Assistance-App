package com.example.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SOSbutton extends AppCompatActivity {

    /**for phone call*/
    Button SOSbutton;
    private EditText editTextNumber;
    private EditText editTextMessage;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sosbutton);

        ActivityCompat.requestPermissions( SOSbutton.this, new String[] {Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS}, PackageManager.PERMISSION_GRANTED);

        editTextMessage = findViewById(R.id.editText);
        editTextNumber = findViewById(R.id.editTextNumber);

        /** additional code for the SOS button to make phone calls
         *
         *SOSbutton = findViewById(R.id.SOSbutton);
         *     SOSbutton.setInClickListener(new View.OnClickListener() {
         *       @Override
         *       public void onClick(View v) {
         *          Intent intent = new Intent(Intent.ACTION_DIAL);
         *          intent.setdata(Url.parse("tel:999'));
         *          startActivity(intent);
         *      }
         *   });
         * }}
         *
         */

        /**JUBA MATEMATE SIN:2106671544 */



    }

    public void sendSMS(View view) {
        String message = editTextMessage.getText().toString();
        String number = editTextNumber.getText().toString();

        SmsManager mySmsManager = SmsManager.getDefault();
        mySmsManager.sendTextMessage(number, null, message, null, null);

    }
}
