package com.example.bmicalculator;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends AppCompatActivity  {



    EditText ediWeight, ediHeight;
    Button buttonBmiCalculate;
    TextView tvResult;
    private Button mapbutton;
    private Button SOSbutton;

        /**code for bmi calculator*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ediWeight = findViewById(R.id.ediWeight);
        ediHeight = findViewById(R.id.ediHeight);
        buttonBmiCalculate = findViewById(R.id.buttonBmiCalculate);
        tvResult = findViewById(R.id.tvResult);

        buttonBmiCalculate.setOnClickListener(new View.OnClickListener() {
                @Override
                        public void onClick(View view) {

                    String sWeight = ediWeight.getText().toString();
                    String sHeight = ediHeight.getText().toString();

                            float weight = Float.parseFloat(sWeight);
                            float height = Float.parseFloat(sHeight);

                            float bmiIndex = weight/ (height);

                            tvResult.setText( "Your BMI Index is  " + bmiIndex+" \n\nBMI Categories:\n" +
                        "Underweight = 18.5\n" +
                        "Normal weight = 18.5-24.9\n" +
                        "Overweight = 25-29.9\n" +
                        "Obesity = BMI of 30 or greater");
                }

        } );


        /**button which switches to maps activity when clicked*/

        mapbutton = (Button) findViewById(R.id.mapbutton );
        mapbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMapsActivity();

            }
        });


        /**code for button which switches to SOS button activity*/

        SOSbutton = (Button) findViewById(R.id.SOSbutton);
        SOSbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSOSbutton();
            }
        });






    }

    public void openSOSbutton() {
        Intent intent = new Intent( this, SOSbutton.class);
        startActivity(intent);
    }

    public void openMapsActivity() {
        Intent intent = new Intent(this, MapsActivity.class);
        startActivity(intent);
    }


}
/**JUBA MATEMATE SIN:2106671544 */